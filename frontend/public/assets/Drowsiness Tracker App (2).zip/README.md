
  # Drowsiness Tracker App

  This is a code bundle for Drowsiness Tracker App. The original project is available at https://www.figma.com/design/qca3j8twCZ3o4jeUPG45uL/Drowsiness-Tracker-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  