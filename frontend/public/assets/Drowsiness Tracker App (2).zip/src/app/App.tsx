import { useState, useEffect, useRef, useCallback } from 'react';
import { GlassesConnection } from './components/GlassesConnection';
import { LiveBlinkMonitor } from './components/LiveBlinkMonitor';
import { SessionRecords } from './components/SessionRecords';
import { WeeklySleepSchedule } from './components/WeeklySleepSchedule';
import { BlinkHistoryChart } from './components/BlinkHistoryChart';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './components/ui/tabs';
import { Eye, Calendar, BarChart3, Activity } from 'lucide-react';

interface BlinkSession {
  timestamp: number;
  blinkCount: number;
  duration: number;
  blinkRate: number;
  avgBlinkRate: number;
  fatigueLevel: 'low' | 'medium' | 'high';
}

export default function App() {
  const [sessions, setSessions] = useState<BlinkSession[]>([]);
  const [isGlassesConnected, setIsGlassesConnected] = useState(false);
  const [currentBlinkRate, setCurrentBlinkRate] = useState(0);
  const currentBlinkRateRef = useRef(0);
  const sessionDataRef = useRef<{
    startTime: number;
    blinkRates: number[];
    totalBlinks: number;
  } | null>(null);
  const sessionIntervalRef = useRef<NodeJS.Timeout | null>(null);

  // Update ref when blink rate changes
  useEffect(() => {
    currentBlinkRateRef.current = currentBlinkRate;
  }, [currentBlinkRate]);

  // Load sessions from localStorage on mount
  useEffect(() => {
    const savedSessions = localStorage.getItem('blinkSessions');
    if (savedSessions) {
      setSessions(JSON.parse(savedSessions));
    }
  }, []);

  // Save sessions to localStorage whenever they change
  useEffect(() => {
    if (sessions.length > 0) {
      localStorage.setItem('blinkSessions', JSON.stringify(sessions));
    }
  }, [sessions]);

  // Handle session tracking when glasses are connected
  useEffect(() => {
    if (isGlassesConnected) {
      // Start a new session
      sessionDataRef.current = {
        startTime: Date.now(),
        blinkRates: [],
        totalBlinks: 0
      };

      // Record session data every second
      sessionIntervalRef.current = setInterval(() => {
        if (sessionDataRef.current) {
          const rate = currentBlinkRateRef.current;
          sessionDataRef.current.blinkRates.push(rate);
          sessionDataRef.current.totalBlinks += Math.floor(rate / 60);
        }
      }, 1000);
    } else {
      // Clear interval
      if (sessionIntervalRef.current) {
        clearInterval(sessionIntervalRef.current);
        sessionIntervalRef.current = null;
      }
      
      // Save session when disconnected
      if (sessionDataRef.current && sessionDataRef.current.blinkRates.length > 0) {
        const sessionData = sessionDataRef.current;
        const duration = Math.floor((Date.now() - sessionData.startTime) / 1000);
        const avgBlinkRate = sessionData.blinkRates.reduce((sum, r) => sum + r, 0) / sessionData.blinkRates.length;
        const maxBlinkRate = Math.max(...sessionData.blinkRates);
        
        let fatigueLevel: 'low' | 'medium' | 'high';
        if (avgBlinkRate < 10) {
          fatigueLevel = 'high';
        } else if (avgBlinkRate < 15) {
          fatigueLevel = 'medium';
        } else {
          fatigueLevel = 'low';
        }

        const newSession: BlinkSession = {
          timestamp: sessionData.startTime,
          blinkCount: sessionData.totalBlinks,
          duration,
          blinkRate: maxBlinkRate,
          avgBlinkRate,
          fatigueLevel
        };

        setSessions(prev => [...prev, newSession]);
      }
      
      sessionDataRef.current = null;
    }

    return () => {
      if (sessionIntervalRef.current) {
        clearInterval(sessionIntervalRef.current);
      }
    };
  }, [isGlassesConnected]);

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto p-4 max-w-7xl">
        {/* Header */}
        <div className="mb-8 text-center">
          <div className="flex items-center justify-center gap-3 mb-2">
            <Eye className="size-8 text-primary" />
            <h1 className="text-4xl">Eye-R</h1>
          </div>
          <p className="text-muted-foreground">
            Smart glasses eye blink tracking and sleep schedule optimization
          </p>
        </div>

        {/* Glasses Connection Status */}
        <div className="mb-6 grid grid-cols-1 lg:grid-cols-2 gap-6">
          <GlassesConnection 
            onConnectionChange={setIsGlassesConnected}
            currentBlinkRate={currentBlinkRate}
          />
          <LiveBlinkMonitor 
            isConnected={isGlassesConnected}
            currentBlinkRate={currentBlinkRate}
            onBlinkRateChange={setCurrentBlinkRate}
          />
        </div>

        {/* Main Content */}
        <Tabs defaultValue="records" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="records" className="flex items-center gap-2">
              <Activity className="size-4" />
              Records
            </TabsTrigger>
            <TabsTrigger value="schedule" className="flex items-center gap-2">
              <Calendar className="size-4" />
              Sleep Schedule
            </TabsTrigger>
            <TabsTrigger value="analytics" className="flex items-center gap-2">
              <BarChart3 className="size-4" />
              Analytics
            </TabsTrigger>
          </TabsList>

          <TabsContent value="records" className="space-y-6">
            <SessionRecords sessions={sessions} />
          </TabsContent>

          <TabsContent value="schedule" className="space-y-6">
            <WeeklySleepSchedule sessions={sessions} />
          </TabsContent>

          <TabsContent value="analytics" className="space-y-6">
            <BlinkHistoryChart sessions={sessions} />
          </TabsContent>
        </Tabs>

        {/* Info Footer */}
        <div className="mt-8 p-4 bg-muted rounded-lg text-sm text-muted-foreground text-center">
          <p>
            <strong>Eye-R:</strong> Your smart glasses automatically track eye blink patterns throughout the day. 
            The app analyzes this data to detect fatigue levels and generate personalized weekly sleep schedules.
          </p>
        </div>
      </div>
    </div>
  );
}