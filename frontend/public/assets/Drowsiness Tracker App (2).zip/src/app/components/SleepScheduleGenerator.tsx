import { Calendar, Moon, Sun, Sparkles, Brain } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { DrowsinessLog } from './DrowsinessTracker';
import { useState } from 'react';

interface SleepScheduleGeneratorProps {
  logs: DrowsinessLog[];
}

interface SleepSchedule {
  day: string;
  bedtime: string;
  wakeTime: string;
  sleepDuration: string;
}

export function SleepScheduleGenerator({ logs }: SleepScheduleGeneratorProps) {
  const [schedule, setSchedule] = useState<SleepSchedule[] | null>(null);
  const [insights, setInsights] = useState<string[]>([]);

  const generateSchedule = () => {
    // Analyze drowsiness patterns
    const hourlyDrowsiness: { [hour: number]: number[] } = {};
    
    logs.forEach(log => {
      const hour = new Date(log.timestamp).getHours();
      if (!hourlyDrowsiness[hour]) {
        hourlyDrowsiness[hour] = [];
      }
      hourlyDrowsiness[hour].push(log.level);
    });

    // Calculate average drowsiness per hour
    const averageByHour: { [hour: number]: number } = {};
    Object.keys(hourlyDrowsiness).forEach(hour => {
      const hourNum = parseInt(hour);
      const levels = hourlyDrowsiness[hourNum];
      averageByHour[hourNum] = levels.reduce((sum, level) => sum + level, 0) / levels.length;
    });

    // Find peak drowsiness hours (best for sleep)
    const peakDrowsinessHour = Object.keys(averageByHour).reduce((a, b) => 
      averageByHour[parseInt(a)] > averageByHour[parseInt(b)] ? a : b
    );

    // Find lowest drowsiness hours (best for waking)
    const lowestDrowsinessHour = Object.keys(averageByHour).reduce((a, b) => 
      averageByHour[parseInt(a)] < averageByHour[parseInt(b)] ? a : b
    );

    // Generate insights
    const newInsights = [];
    const avgDrowsiness = logs.reduce((sum, log) => sum + log.level, 0) / logs.length;
    
    if (avgDrowsiness > 6) {
      newInsights.push('Your average drowsiness is high. Consider increasing sleep duration.');
    } else if (avgDrowsiness < 4) {
      newInsights.push('Your energy levels look good! Current sleep pattern seems effective.');
    }

    if (parseInt(peakDrowsinessHour) < 20) {
      newInsights.push(`You show high drowsiness around ${peakDrowsinessHour}:00. Consider an earlier bedtime.`);
    }

    newInsights.push('Consistent sleep schedule improves sleep quality by 35%.');
    newInsights.push('Avoid screens 1 hour before bedtime for better sleep.');

    setInsights(newInsights);

    // Generate optimal schedule
    const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
    const optimalBedtime = Math.max(21, parseInt(peakDrowsinessHour) - 1);
    const optimalWakeTime = Math.min(7, parseInt(lowestDrowsinessHour) + 1);
    
    const newSchedule = days.map(day => {
      // Adjust weekend slightly
      const isWeekend = day === 'Saturday' || day === 'Sunday';
      const bedtime = isWeekend ? optimalBedtime + 1 : optimalBedtime;
      const wakeTime = isWeekend ? optimalWakeTime + 1 : optimalWakeTime;
      
      return {
        day,
        bedtime: `${bedtime % 24}:00 ${bedtime >= 12 ? 'PM' : 'AM'}`,
        wakeTime: `${wakeTime % 12 || 12}:00 AM`,
        sleepDuration: `${(24 - bedtime + wakeTime) % 24} hours`,
      };
    });

    setSchedule(newSchedule);
  };

  const getRecommendedSleepHours = () => {
    const avgDrowsiness = logs.reduce((sum, log) => sum + log.level, 0) / logs.length;
    if (avgDrowsiness > 7) return '8-9 hours';
    if (avgDrowsiness > 5) return '7-8 hours';
    return '7-8 hours';
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Calendar className="size-5" />
          Weekly Sleep Schedule
        </CardTitle>
        <CardDescription>
          AI-generated schedule based on your drowsiness patterns
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {logs.length < 5 ? (
          <div className="text-center py-8 space-y-4">
            <Brain className="size-12 mx-auto text-muted-foreground" />
            <div>
              <h3 className="text-lg mb-2">Need More Data</h3>
              <p className="text-sm text-muted-foreground">
                Log at least 5 drowsiness entries throughout different times of day to generate a personalized schedule.
              </p>
              <p className="text-sm text-muted-foreground mt-2">
                Current entries: {logs.length}/5
              </p>
            </div>
          </div>
        ) : (
          <>
            {schedule === null ? (
              <div className="text-center py-8 space-y-4">
                <Sparkles className="size-12 mx-auto text-primary" />
                <div>
                  <h3 className="text-lg mb-2">Ready to Generate</h3>
                  <p className="text-sm text-muted-foreground mb-4">
                    We have enough data to create your personalized sleep schedule
                  </p>
                  <Button onClick={generateSchedule} size="lg">
                    <Sparkles className="size-4 mr-2" />
                    Generate My Schedule
                  </Button>
                </div>
              </div>
            ) : (
              <>
                {/* Insights */}
                <div className="space-y-3">
                  <h3 className="flex items-center gap-2">
                    <Brain className="size-4" />
                    Insights
                  </h3>
                  <div className="space-y-2">
                    {insights.map((insight, index) => (
                      <div key={index} className="flex items-start gap-2 text-sm">
                        <Sparkles className="size-4 text-primary mt-0.5 flex-shrink-0" />
                        <span className="text-muted-foreground">{insight}</span>
                      </div>
                    ))}
                  </div>
                  <div className="flex items-center gap-2 mt-4">
                    <Badge variant="secondary">
                      Recommended: {getRecommendedSleepHours()} per night
                    </Badge>
                  </div>
                </div>

                {/* Schedule */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <h3>Your Personalized Schedule</h3>
                    <Button variant="outline" size="sm" onClick={generateSchedule}>
                      Regenerate
                    </Button>
                  </div>
                  <div className="space-y-2">
                    {schedule.map((item) => (
                      <div
                        key={item.day}
                        className="flex items-center justify-between p-3 rounded-lg border bg-card hover:bg-accent/50 transition-colors"
                      >
                        <div className="flex-1">
                          <div className="font-medium">{item.day}</div>
                          <div className="text-sm text-muted-foreground">{item.sleepDuration}</div>
                        </div>
                        <div className="flex items-center gap-4 text-sm">
                          <div className="flex items-center gap-1.5">
                            <Moon className="size-4 text-indigo-500" />
                            <span>{item.bedtime}</span>
                          </div>
                          <div className="flex items-center gap-1.5">
                            <Sun className="size-4 text-amber-500" />
                            <span>{item.wakeTime}</span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </>
            )}
          </>
        )}
      </CardContent>
    </Card>
  );
}
