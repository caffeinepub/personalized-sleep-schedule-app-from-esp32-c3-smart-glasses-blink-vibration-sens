import { Clock, Eye, Calendar, TrendingDown, TrendingUp, Minus } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { ScrollArea } from './ui/scroll-area';

interface BlinkSession {
  timestamp: number;
  blinkCount: number;
  duration: number;
  blinkRate: number;
  avgBlinkRate: number;
  fatigueLevel: 'low' | 'medium' | 'high';
}

interface SessionRecordsProps {
  sessions: BlinkSession[];
}

export function SessionRecords({ sessions }: SessionRecordsProps) {
  const sortedSessions = [...sessions].sort((a, b) => b.timestamp - a.timestamp);

  const getFatigueBadge = (level: string) => {
    switch (level) {
      case 'low':
        return <Badge variant="default" className="bg-green-500">Low Fatigue</Badge>;
      case 'medium':
        return <Badge variant="secondary">Moderate</Badge>;
      case 'high':
        return <Badge variant="destructive">High Fatigue</Badge>;
      default:
        return <Badge variant="outline">Unknown</Badge>;
    }
  };

  const getTrendIcon = (rate: number) => {
    if (rate < 10) return <TrendingDown className="size-4 text-red-500" />;
    if (rate < 15) return <Minus className="size-4 text-yellow-500" />;
    return <TrendingUp className="size-4 text-green-500" />;
  };

  const formatDuration = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    
    if (hours > 0) {
      return `${hours}h ${minutes}m`;
    }
    return `${minutes}m ${secs}s`;
  };

  const formatDate = (timestamp: number) => {
    const date = new Date(timestamp);
    const today = new Date();
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);

    if (date.toDateString() === today.toDateString()) {
      return `Today at ${date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })}`;
    } else if (date.toDateString() === yesterday.toDateString()) {
      return `Yesterday at ${date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })}`;
    } else {
      return date.toLocaleDateString('en-US', { 
        month: 'short', 
        day: 'numeric', 
        hour: '2-digit', 
        minute: '2-digit' 
      });
    }
  };

  const getTotalStats = () => {
    if (sessions.length === 0) {
      return {
        totalDuration: 0,
        totalBlinks: 0,
        avgRate: 0,
        sessionsToday: 0
      };
    }

    const today = new Date().toDateString();
    const sessionsToday = sessions.filter(s => 
      new Date(s.timestamp).toDateString() === today
    ).length;

    const totalDuration = sessions.reduce((sum, s) => sum + s.duration, 0);
    const totalBlinks = sessions.reduce((sum, s) => sum + s.blinkCount, 0);
    const avgRate = sessions.reduce((sum, s) => sum + s.avgBlinkRate, 0) / sessions.length;

    return { totalDuration, totalBlinks, avgRate, sessionsToday };
  };

  const stats = getTotalStats();

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Calendar className="size-5" />
          Session Records
        </CardTitle>
        <CardDescription>
          Historical tracking sessions from your glasses
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Summary Stats */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          <div className="p-3 bg-muted rounded-lg text-center">
            <div className="text-2xl font-mono">{sessions.length}</div>
            <div className="text-xs text-muted-foreground">Total Sessions</div>
          </div>
          <div className="p-3 bg-muted rounded-lg text-center">
            <div className="text-2xl font-mono">{stats.sessionsToday}</div>
            <div className="text-xs text-muted-foreground">Today</div>
          </div>
          <div className="p-3 bg-muted rounded-lg text-center">
            <div className="text-2xl font-mono">{Math.floor(stats.totalDuration / 3600)}h</div>
            <div className="text-xs text-muted-foreground">Total Time</div>
          </div>
          <div className="p-3 bg-muted rounded-lg text-center">
            <div className="text-2xl font-mono">{stats.avgRate.toFixed(1)}</div>
            <div className="text-xs text-muted-foreground">Avg Rate</div>
          </div>
        </div>

        {/* Session List */}
        {sessions.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground">
            <Calendar className="size-12 mx-auto mb-4 opacity-20" />
            <p>No tracking sessions yet</p>
            <p className="text-sm mt-2">Connect your glasses to start recording</p>
          </div>
        ) : (
          <ScrollArea className="h-[400px] pr-4">
            <div className="space-y-3">
              {sortedSessions.map((session, index) => (
                <div
                  key={index}
                  className="p-4 border rounded-lg hover:bg-muted/50 transition-colors"
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <Clock className="size-4 text-muted-foreground" />
                        <span className="text-sm">{formatDate(session.timestamp)}</span>
                      </div>
                      <div className="text-xs text-muted-foreground">
                        Duration: {formatDuration(session.duration)}
                      </div>
                    </div>
                    {getFatigueBadge(session.fatigueLevel)}
                  </div>

                  <div className="grid grid-cols-3 gap-3 text-sm">
                    <div className="flex items-center gap-2">
                      <Eye className="size-4 text-muted-foreground" />
                      <div>
                        <div className="text-muted-foreground text-xs">Total Blinks</div>
                        <div className="font-medium">{session.blinkCount}</div>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      {getTrendIcon(session.avgBlinkRate)}
                      <div>
                        <div className="text-muted-foreground text-xs">Avg Rate</div>
                        <div className="font-medium">{session.avgBlinkRate.toFixed(1)}/min</div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <div>
                        <div className="text-muted-foreground text-xs">Peak Rate</div>
                        <div className="font-medium">{session.blinkRate.toFixed(1)}/min</div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </ScrollArea>
        )}
      </CardContent>
    </Card>
  );
}
