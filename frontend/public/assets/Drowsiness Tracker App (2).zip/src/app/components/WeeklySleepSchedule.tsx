import { useState, useEffect } from 'react';
import { Calendar, Moon, Sun, Clock, TrendingUp } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';

interface BlinkSession {
  timestamp: number;
  blinkCount: number;
  duration: number;
  blinkRate: number;
  avgBlinkRate: number;
  fatigueLevel: 'low' | 'medium' | 'high';
}

interface SleepRecommendation {
  day: string;
  date: string;
  bedtime: string;
  wakeTime: string;
  sleepDuration: number;
  fatigueLevel: 'low' | 'medium' | 'high';
  recommendedNap?: string;
}

interface WeeklySleepScheduleProps {
  sessions: BlinkSession[];
}

export function WeeklySleepSchedule({ sessions }: WeeklySleepScheduleProps) {
  const [schedule, setSchedule] = useState<SleepRecommendation[]>([]);

  useEffect(() => {
    generateSchedule();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sessions]);

  const generateSchedule = () => {
    const today = new Date();
    const weekSchedule: SleepRecommendation[] = [];

    for (let i = 0; i < 7; i++) {
      const date = new Date(today);
      date.setDate(today.getDate() + i);
      
      const dayName = date.toLocaleDateString('en-US', { weekday: 'long' });
      const dateStr = date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });

      // Analyze blink patterns from sessions
      const avgBlinkRate = sessions.length > 0
        ? sessions.reduce((sum, s) => sum + s.blinkRate, 0) / sessions.length
        : 15;

      // Determine fatigue level based on blink rate
      let fatigueLevel: 'low' | 'medium' | 'high';
      let sleepDuration: number;
      let baseBedtime: number;

      if (avgBlinkRate < 10) {
        fatigueLevel = 'high';
        sleepDuration = 9;
        baseBedtime = 21; // 9 PM
      } else if (avgBlinkRate < 15) {
        fatigueLevel = 'medium';
        sleepDuration = 8;
        baseBedtime = 22; // 10 PM
      } else {
        fatigueLevel = 'low';
        sleepDuration = 7.5;
        baseBedtime = 22.5; // 10:30 PM
      }

      // Adjust for weekends
      if (date.getDay() === 0 || date.getDay() === 6) {
        baseBedtime += 0.5;
        sleepDuration += 0.5;
      }

      const bedtimeHour = Math.floor(baseBedtime);
      const bedtimeMin = (baseBedtime % 1) * 60;
      const bedtime = `${bedtimeHour > 12 ? bedtimeHour - 12 : bedtimeHour}:${bedtimeMin.toString().padStart(2, '0')} ${bedtimeHour >= 12 ? 'PM' : 'AM'}`;

      const wakeTimeDecimal = (baseBedtime + sleepDuration) % 24;
      const wakeHour = Math.floor(wakeTimeDecimal);
      const wakeMin = (wakeTimeDecimal % 1) * 60;
      const wakeTime = `${wakeHour > 12 ? wakeHour - 12 : wakeHour === 0 ? 12 : wakeHour}:${wakeMin.toString().padStart(2, '0')} ${wakeHour >= 12 ? 'PM' : 'AM'}`;

      const recommendation: SleepRecommendation = {
        day: dayName,
        date: dateStr,
        bedtime,
        wakeTime,
        sleepDuration,
        fatigueLevel,
        recommendedNap: fatigueLevel === 'high' ? '2:00 PM - 2:30 PM' : undefined
      };

      weekSchedule.push(recommendation);
    }

    setSchedule(weekSchedule);
  };

  const getFatigueBadgeVariant = (level: string) => {
    switch (level) {
      case 'low':
        return 'default';
      case 'medium':
        return 'secondary';
      case 'high':
        return 'destructive';
      default:
        return 'default';
    }
  };

  const getAverageBlinkRate = () => {
    if (sessions.length === 0) return 'N/A';
    const avg = sessions.reduce((sum, s) => sum + s.blinkRate, 0) / sessions.length;
    return avg.toFixed(1);
  };

  const getTotalSessions = () => sessions.length;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Calendar className="size-5" />
          Weekly Sleep Schedule
        </CardTitle>
        <CardDescription>
          Personalized sleep recommendations based on your blink patterns
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Analytics Summary */}
        <div className="grid grid-cols-2 gap-4 p-4 bg-muted rounded-lg">
          <div className="flex items-center gap-3">
            <TrendingUp className="size-8 text-primary" />
            <div>
              <div className="text-2xl font-mono">{getAverageBlinkRate()}</div>
              <div className="text-sm text-muted-foreground">Avg Blinks/Min</div>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Clock className="size-8 text-primary" />
            <div>
              <div className="text-2xl font-mono">{getTotalSessions()}</div>
              <div className="text-sm text-muted-foreground">Total Sessions</div>
            </div>
          </div>
        </div>

        {/* Weekly Schedule */}
        <div className="space-y-3">
          {schedule.map((day, index) => (
            <div
              key={index}
              className="p-4 border rounded-lg hover:bg-muted/50 transition-colors"
            >
              <div className="flex items-start justify-between mb-3">
                <div>
                  <div className="font-medium">{day.day}</div>
                  <div className="text-sm text-muted-foreground">{day.date}</div>
                </div>
                <Badge variant={getFatigueBadgeVariant(day.fatigueLevel)}>
                  {day.fatigueLevel} fatigue
                </Badge>
              </div>

              <div className="grid grid-cols-2 gap-4 text-sm">
                <div className="flex items-center gap-2">
                  <Moon className="size-4 text-muted-foreground" />
                  <div>
                    <div className="text-muted-foreground">Bedtime</div>
                    <div className="font-medium">{day.bedtime}</div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Sun className="size-4 text-muted-foreground" />
                  <div>
                    <div className="text-muted-foreground">Wake Time</div>
                    <div className="font-medium">{day.wakeTime}</div>
                  </div>
                </div>
              </div>

              <div className="mt-3 pt-3 border-t text-sm">
                <div className="text-muted-foreground">
                  Sleep Duration: <span className="font-medium text-foreground">{day.sleepDuration}h</span>
                </div>
                {day.recommendedNap && (
                  <div className="text-muted-foreground mt-1">
                    Recommended Nap: <span className="font-medium text-foreground">{day.recommendedNap}</span>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>

        {sessions.length === 0 && (
          <div className="text-center py-8 text-muted-foreground">
            <p>Start tracking your blinks to generate a personalized sleep schedule.</p>
            <p className="text-sm mt-2">Complete at least one tracking session to see recommendations.</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}