import { useState, useEffect, useRef } from 'react';
import { Glasses, Wifi, WifiOff, Activity, Bluetooth, AlertCircle, Zap } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Alert, AlertDescription } from './ui/alert';

interface GlassesConnectionProps {
  onConnectionChange: (connected: boolean) => void;
  currentBlinkRate: number;
}

export function GlassesConnection({ onConnectionChange, currentBlinkRate }: GlassesConnectionProps) {
  const [isConnected, setIsConnected] = useState(false);
  const [batteryLevel, setBatteryLevel] = useState(85);
  const [lastSync, setLastSync] = useState<Date>(new Date());
  const [deviceName, setDeviceName] = useState<string>('');
  const [isConnecting, setIsConnecting] = useState(false);
  const [error, setError] = useState<string>('');
  const [bluetoothSupported, setBluetoothSupported] = useState(true);
  const [demoMode, setDemoMode] = useState(false);
  
  const deviceRef = useRef<BluetoothDevice | null>(null);
  const serverRef = useRef<BluetoothRemoteGATTServer | null>(null);
  const batteryCharacteristicRef = useRef<BluetoothRemoteGATTCharacteristic | null>(null);

  // Check Bluetooth support on mount
  useEffect(() => {
    if (!navigator.bluetooth) {
      setBluetoothSupported(false);
    }
  }, []);

  const handleToggleConnection = async () => {
    if (isConnected) {
      // Disconnect
      await disconnectDevice();
    } else {
      // Try Bluetooth first, fall back to demo mode if it fails
      await connectToBluetoothDevice();
    }
  };

  const connectToDemoMode = () => {
    setDemoMode(true);
    setDeviceName('Eye-R Pro (Demo)');
    setBatteryLevel(85 + Math.random() * 15);
    setIsConnected(true);
    setLastSync(new Date());
    setError('');
    onConnectionChange(true);
  };

  const connectToBluetoothDevice = async () => {
    if (!navigator.bluetooth) {
      // Fall back to demo mode
      connectToDemoMode();
      return;
    }

    setIsConnecting(true);
    setError('');

    try {
      // Request Bluetooth device
      const device = await navigator.bluetooth.requestDevice({
        filters: [
          { services: ['battery_service'] },
          { namePrefix: 'Blink' },
          { namePrefix: 'Glass' },
        ],
        optionalServices: ['battery_service', 'device_information']
      });

      deviceRef.current = device;
      setDeviceName(device.name || 'Unknown Device');
      setDemoMode(false);

      // Listen for disconnection
      device.addEventListener('gattserverdisconnected', handleDeviceDisconnected);

      // Connect to GATT server
      const server = await device.gatt?.connect();
      if (!server) {
        throw new Error('Failed to connect to GATT server');
      }
      serverRef.current = server;

      // Try to get battery service
      try {
        const batteryService = await server.getPrimaryService('battery_service');
        const batteryCharacteristic = await batteryService.getCharacteristic('battery_level');
        batteryCharacteristicRef.current = batteryCharacteristic;
        
        // Read initial battery level
        const batteryValue = await batteryCharacteristic.readValue();
        const battery = batteryValue.getUint8(0);
        setBatteryLevel(battery);

        // Subscribe to battery notifications
        await batteryCharacteristic.startNotifications();
        batteryCharacteristic.addEventListener('characteristicvaluechanged', handleBatteryChange);
      } catch (err) {
        console.log('Battery service not available, using simulated battery');
        // Use simulated battery if real one not available
        setBatteryLevel(85 + Math.random() * 15);
      }

      setIsConnected(true);
      setIsConnecting(false);
      setLastSync(new Date());
      onConnectionChange(true);

    } catch (err) {
      setIsConnecting(false);
      if (err instanceof Error) {
        if (err.name === 'NotFoundError') {
          // User cancelled or no device found - use demo mode
          connectToDemoMode();
          return;
        } else if (err.name === 'SecurityError') {
          // Permissions policy issue - use demo mode
          console.log('Bluetooth blocked by permissions policy, using demo mode');
          connectToDemoMode();
          return;
        } else if (err.message.includes('permissions policy')) {
          // Permissions policy issue - use demo mode
          console.log('Bluetooth blocked by permissions policy, using demo mode');
          connectToDemoMode();
          return;
        } else {
          // Other errors - try demo mode as fallback
          console.warn('Bluetooth connection failed, using demo mode:', err);
          connectToDemoMode();
          return;
        }
      } else {
        // Unknown error - use demo mode
        connectToDemoMode();
        return;
      }
    }
  };

  const disconnectDevice = async () => {
    try {
      // Stop notifications
      if (batteryCharacteristicRef.current) {
        try {
          await batteryCharacteristicRef.current.stopNotifications();
        } catch (err) {
          console.log('Could not stop notifications:', err);
        }
      }

      // Disconnect from GATT server
      if (serverRef.current?.connected) {
        serverRef.current.disconnect();
      }

      // Clean up references
      deviceRef.current = null;
      serverRef.current = null;
      batteryCharacteristicRef.current = null;

      setIsConnected(false);
      setDeviceName('');
      setDemoMode(false);
      onConnectionChange(false);
    } catch (err) {
      console.error('Disconnection error:', err);
    }
  };

  const handleDeviceDisconnected = () => {
    console.log('Device disconnected');
    setIsConnected(false);
    setDeviceName('');
    setDemoMode(false);
    onConnectionChange(false);
    setError('Device disconnected unexpectedly');
  };

  const handleBatteryChange = (event: Event) => {
    const target = event.target as BluetoothRemoteGATTCharacteristic;
    const value = target.value;
    if (value) {
      const battery = value.getUint8(0);
      setBatteryLevel(battery);
    }
  };

  useEffect(() => {
    if (isConnected) {
      // Simulate battery drain if not using real battery service
      if (!batteryCharacteristicRef.current) {
        const batteryInterval = setInterval(() => {
          setBatteryLevel(prev => Math.max(0, prev - Math.random() * 0.5));
        }, 30000);

        return () => clearInterval(batteryInterval);
      }

      // Update last sync time
      const syncInterval = setInterval(() => {
        setLastSync(new Date());
      }, 5000);

      return () => {
        clearInterval(syncInterval);
      };
    }
  }, [isConnected]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (deviceRef.current) {
        disconnectDevice();
      }
    };
  }, []);

  const getStatusColor = () => {
    if (!isConnected) return 'text-muted-foreground';
    if (currentBlinkRate < 10) return 'text-red-500';
    if (currentBlinkRate < 15) return 'text-yellow-500';
    return 'text-green-500';
  };

  const getBatteryColor = () => {
    if (batteryLevel > 50) return 'text-green-500';
    if (batteryLevel > 20) return 'text-yellow-500';
    return 'text-red-500';
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Glasses className="size-5" />
            Smart Glasses Status
          </div>
          <Badge variant={isConnected ? "default" : "secondary"}>
            {isConnected ? (
              <>
                {demoMode ? (
                  <><Zap className="size-3 mr-1" /> Demo Mode</>
                ) : (
                  <><Bluetooth className="size-3 mr-1" /> Connected</>
                )}
              </>
            ) : (
              <><WifiOff className="size-3 mr-1" /> Disconnected</>
            )}
          </Badge>
        </CardTitle>
        <CardDescription>
          {isConnected && deviceName ? deviceName : 'Eye-R Pro - Eye Tracking Glasses'}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {error && (
          <Alert variant="destructive">
            <AlertCircle className="size-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        <div className="grid grid-cols-2 gap-4">
          {/* Current Blink Rate */}
          <div className="p-4 bg-muted rounded-lg">
            <div className="flex items-center gap-2 mb-1">
              <Activity className={`size-4 ${getStatusColor()}`} />
              <div className="text-sm text-muted-foreground">Blink Rate</div>
            </div>
            <div className={`text-2xl font-mono ${getStatusColor()}`}>
              {isConnected ? `${currentBlinkRate.toFixed(1)}` : '--'}
            </div>
            <div className="text-xs text-muted-foreground">blinks/min</div>
          </div>

          {/* Battery Level */}
          <div className="p-4 bg-muted rounded-lg">
            <div className="text-sm text-muted-foreground mb-1">Battery</div>
            <div className={`text-2xl font-mono ${getBatteryColor()}`}>
              {isConnected ? `${batteryLevel.toFixed(0)}%` : '--'}
            </div>
            <div className="text-xs text-muted-foreground">
              {isConnected ? `~${Math.floor(batteryLevel / 10)}h remaining` : 'Not connected'}
            </div>
          </div>
        </div>

        {isConnected && (
          <div className="text-sm text-muted-foreground text-center">
            Last sync: {lastSync.toLocaleTimeString()}
          </div>
        )}

        <Button 
          onClick={handleToggleConnection} 
          className="w-full"
          variant={isConnected ? "outline" : "default"}
          disabled={isConnecting}
        >
          {isConnecting ? (
            <>
              <Bluetooth className="size-4 mr-2 animate-pulse" />
              Connecting...
            </>
          ) : isConnected ? (
            'Disconnect Glasses'
          ) : (
            <>
              <Bluetooth className="size-4 mr-2" />
              Connect Glasses
            </>
          )}
        </Button>

        {!isConnected && (
          <div className="text-xs text-center text-muted-foreground">
            {bluetoothSupported ? (
              <>Click to connect. Will try Bluetooth first, then demo mode if unavailable.</>
            ) : (
              <>Bluetooth not supported. Demo mode will be used.</>
            )}
          </div>
        )}

        {isConnected && demoMode && (
          <div className="text-xs text-center text-muted-foreground bg-blue-500/10 p-2 rounded">
            Running in demo mode - simulated glasses connection
          </div>
        )}
      </CardContent>
    </Card>
  );
}