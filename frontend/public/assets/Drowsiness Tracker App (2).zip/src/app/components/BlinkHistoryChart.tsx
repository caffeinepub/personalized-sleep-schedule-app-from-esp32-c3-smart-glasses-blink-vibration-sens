import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend, LineChart, Line } from 'recharts';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Activity } from 'lucide-react';

interface BlinkSession {
  timestamp: number;
  blinkCount: number;
  duration: number;
  blinkRate: number;
  avgBlinkRate: number;
  fatigueLevel: 'low' | 'medium' | 'high';
}

interface BlinkHistoryChartProps {
  sessions: BlinkSession[];
}

export function BlinkHistoryChart({ sessions }: BlinkHistoryChartProps) {
  // Prepare data for the chart
  const chartData = sessions.slice(-10).map((session, index) => {
    const date = new Date(session.timestamp);
    return {
      name: date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }),
      'Blink Rate': parseFloat(session.blinkRate.toFixed(1)),
      'Total Blinks': session.blinkCount,
      'Duration (min)': parseFloat((session.duration / 60).toFixed(1))
    };
  });

  // Calculate average blink rate with zones
  const avgBlinkRate = sessions.length > 0
    ? sessions.reduce((sum, s) => sum + s.blinkRate, 0) / sessions.length
    : 0;

  const getAlertLevel = (rate: number) => {
    if (rate < 10) return { level: 'High Fatigue', color: 'text-red-500' };
    if (rate < 15) return { level: 'Moderate Fatigue', color: 'text-yellow-500' };
    return { level: 'Normal', color: 'text-green-500' };
  };

  const alertStatus = getAlertLevel(avgBlinkRate);

  if (sessions.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="size-5" />
            Blink History
          </CardTitle>
          <CardDescription>
            Your blink rate trends and patterns over time
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center h-64 text-muted-foreground">
            No session data available. Start tracking to see your history.
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Activity className="size-5" />
          Blink History
        </CardTitle>
        <CardDescription>
          Your blink rate trends and patterns over time
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Alert Status */}
        <div className="p-4 bg-muted rounded-lg">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-sm text-muted-foreground">Current Status</div>
              <div className={`text-xl font-medium ${alertStatus.color}`}>
                {alertStatus.level}
              </div>
            </div>
            <div>
              <div className="text-sm text-muted-foreground">Avg Blink Rate</div>
              <div className="text-xl font-mono">
                {avgBlinkRate.toFixed(1)} /min
              </div>
            </div>
          </div>
        </div>

        {/* Blink Rate Chart */}
        <div>
          <h4 className="mb-4">Blink Rate Over Time</h4>
          <ResponsiveContainer width="100%" height={250}>
            <LineChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis 
                dataKey="name" 
                tick={{ fontSize: 12 }}
                angle={-45}
                textAnchor="end"
                height={80}
              />
              <YAxis 
                label={{ value: 'Blinks per Minute', angle: -90, position: 'insideLeft' }}
              />
              <Tooltip />
              <Legend />
              <Line 
                type="monotone" 
                dataKey="Blink Rate" 
                stroke="#8884d8" 
                strokeWidth={2}
                dot={{ r: 4 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Reference Lines Info */}
        <div className="grid grid-cols-3 gap-4 text-center text-sm">
          <div className="p-3 bg-red-500/10 rounded border border-red-500/20">
            <div className="text-red-500">&lt; 10</div>
            <div className="text-muted-foreground mt-1">High Fatigue</div>
          </div>
          <div className="p-3 bg-yellow-500/10 rounded border border-yellow-500/20">
            <div className="text-yellow-500">10-15</div>
            <div className="text-muted-foreground mt-1">Moderate</div>
          </div>
          <div className="p-3 bg-green-500/10 rounded border border-green-500/20">
            <div className="text-green-500">&gt; 15</div>
            <div className="text-muted-foreground mt-1">Normal</div>
          </div>
        </div>

        {/* Duration Chart */}
        <div>
          <h4 className="mb-4">Session Duration & Total Blinks</h4>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis 
                dataKey="name" 
                tick={{ fontSize: 12 }}
                angle={-45}
                textAnchor="end"
                height={80}
              />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="Total Blinks" fill="#82ca9d" />
              <Bar dataKey="Duration (min)" fill="#ffc658" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
}