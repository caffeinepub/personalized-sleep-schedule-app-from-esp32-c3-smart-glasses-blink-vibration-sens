import { useState } from 'react';
import { Plus, Clock, Activity } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Slider } from './ui/slider';
import { Label } from './ui/label';
import { toast } from 'sonner';

export interface DrowsinessLog {
  id: string;
  timestamp: Date;
  level: number;
  note?: string;
}

interface DrowsinessTrackerProps {
  onLogAdded: (log: DrowsinessLog) => void;
}

export function DrowsinessTracker({ onLogAdded }: DrowsinessTrackerProps) {
  const [drowsinessLevel, setDrowsinessLevel] = useState([5]);

  const handleLogDrowsiness = () => {
    const newLog: DrowsinessLog = {
      id: Date.now().toString(),
      timestamp: new Date(),
      level: drowsinessLevel[0],
    };

    onLogAdded(newLog);
    toast.success('Drowsiness level logged successfully');
  };

  const getLevelDescription = (level: number) => {
    if (level <= 2) return 'Wide Awake';
    if (level <= 4) return 'Alert';
    if (level <= 6) return 'Slightly Drowsy';
    if (level <= 8) return 'Very Drowsy';
    return 'Extremely Drowsy';
  };

  const getLevelColor = (level: number) => {
    if (level <= 2) return 'text-green-600';
    if (level <= 4) return 'text-blue-600';
    if (level <= 6) return 'text-yellow-600';
    if (level <= 8) return 'text-orange-600';
    return 'text-red-600';
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Activity className="size-5" />
          Track Drowsiness
        </CardTitle>
        <CardDescription>
          Log your current drowsiness level to help generate an optimal sleep schedule
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <Label>Current Drowsiness Level</Label>
            <div className="flex items-center gap-2">
              <Clock className="size-4 text-muted-foreground" />
              <span className="text-sm text-muted-foreground">
                {new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </span>
            </div>
          </div>
          
          <div className="space-y-4">
            <Slider
              value={drowsinessLevel}
              onValueChange={setDrowsinessLevel}
              min={1}
              max={10}
              step={1}
              className="w-full"
            />
            
            <div className="flex items-center justify-between">
              <div className="text-center">
                <div className={`text-3xl ${getLevelColor(drowsinessLevel[0])}`}>
                  {drowsinessLevel[0]}
                </div>
                <div className={`text-sm ${getLevelColor(drowsinessLevel[0])}`}>
                  {getLevelDescription(drowsinessLevel[0])}
                </div>
              </div>
              
              <div className="flex gap-2 text-xs text-muted-foreground">
                <div>1 = Awake</div>
                <div>•</div>
                <div>10 = Exhausted</div>
              </div>
            </div>
          </div>
        </div>

        <Button onClick={handleLogDrowsiness} className="w-full" size="lg">
          <Plus className="size-4 mr-2" />
          Log Drowsiness Level
        </Button>
      </CardContent>
    </Card>
  );
}
