import { useEffect, useState } from 'react';
import { Eye, AlertTriangle, CheckCircle, AlertCircle } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Progress } from './ui/progress';
import { Alert, AlertDescription, AlertTitle } from './ui/alert';

interface LiveBlinkMonitorProps {
  isConnected: boolean;
  currentBlinkRate: number;
  onBlinkRateChange: (rate: number) => void;
}

export function LiveBlinkMonitor({ isConnected, currentBlinkRate, onBlinkRateChange }: LiveBlinkMonitorProps) {
  const [recentBlinks, setRecentBlinks] = useState<number[]>([]);
  const [alertLevel, setAlertLevel] = useState<'normal' | 'warning' | 'critical'>('normal');

  useEffect(() => {
    if (!isConnected) {
      setRecentBlinks([]);
      return;
    }

    // Simulate real-time blink detection from glasses
    const interval = setInterval(() => {
      // Generate realistic blink pattern (normally distributed around average)
      const baseRate = 12 + Math.random() * 8; // 12-20 blinks/min
      const variation = (Math.random() - 0.5) * 4;
      const newRate = Math.max(5, Math.min(25, baseRate + variation));
      
      onBlinkRateChange(newRate);
      
      // Keep last 30 seconds of data
      setRecentBlinks(prev => {
        const updated = [...prev, newRate];
        return updated.slice(-30);
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [isConnected, onBlinkRateChange]);

  useEffect(() => {
    // Determine alert level based on blink rate
    if (currentBlinkRate < 10) {
      setAlertLevel('critical');
    } else if (currentBlinkRate < 15) {
      setAlertLevel('warning');
    } else {
      setAlertLevel('normal');
    }
  }, [currentBlinkRate]);

  const getAlertIcon = () => {
    switch (alertLevel) {
      case 'critical':
        return <AlertTriangle className="size-4" />;
      case 'warning':
        return <AlertCircle className="size-4" />;
      default:
        return <CheckCircle className="size-4" />;
    }
  };

  const getAlertVariant = (): "default" | "destructive" => {
    switch (alertLevel) {
      case 'critical':
        return 'destructive';
      default:
        return 'default';
    }
  };

  const getAlertMessage = () => {
    switch (alertLevel) {
      case 'critical':
        return {
          title: 'High Fatigue Detected',
          description: 'Your blink rate is significantly below normal. Consider taking a break or resting.'
        };
      case 'warning':
        return {
          title: 'Moderate Fatigue',
          description: 'Your blink rate indicates some fatigue. Take breaks regularly.'
        };
      default:
        return {
          title: 'Normal Activity',
          description: 'Your blink patterns are within normal range.'
        };
    }
  };

  const calculateAverage = () => {
    if (recentBlinks.length === 0) return 0;
    return recentBlinks.reduce((sum, val) => sum + val, 0) / recentBlinks.length;
  };

  const normalizedProgress = ((currentBlinkRate - 5) / 20) * 100;

  if (!isConnected) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Eye className="size-5" />
            Live Blink Monitor
          </CardTitle>
          <CardDescription>
            Real-time eye blink tracking from your glasses
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col items-center justify-center h-48 text-muted-foreground">
            <Eye className="size-12 mb-4 opacity-20" />
            <p>Connect your glasses to start monitoring</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  const alertInfo = getAlertMessage();

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Eye className="size-5" />
          Live Blink Monitor
        </CardTitle>
        <CardDescription>
          Real-time eye blink tracking from your glasses
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Current Blink Rate Display */}
        <div className="text-center p-6 bg-muted rounded-lg">
          <div className="text-sm text-muted-foreground mb-2">Current Blink Rate</div>
          <div className="text-6xl font-mono mb-2">
            {currentBlinkRate.toFixed(1)}
          </div>
          <div className="text-muted-foreground">blinks per minute</div>
        </div>

        {/* Visual Indicator */}
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Fatigue Level</span>
            <span className="font-medium">
              {alertLevel === 'critical' ? 'High' : alertLevel === 'warning' ? 'Moderate' : 'Low'}
            </span>
          </div>
          <Progress value={normalizedProgress} className="h-3" />
          <div className="flex justify-between text-xs text-muted-foreground">
            <span>High Fatigue (5)</span>
            <span>Normal (15-20)</span>
            <span>Alert (25+)</span>
          </div>
        </div>

        {/* Alert Message */}
        <Alert variant={getAlertVariant()}>
          {getAlertIcon()}
          <AlertTitle>{alertInfo.title}</AlertTitle>
          <AlertDescription>{alertInfo.description}</AlertDescription>
        </Alert>

        {/* Statistics */}
        <div className="grid grid-cols-2 gap-4">
          <div className="text-center p-3 border rounded-lg">
            <div className="text-2xl font-mono">{calculateAverage().toFixed(1)}</div>
            <div className="text-sm text-muted-foreground">30s Average</div>
          </div>
          <div className="text-center p-3 border rounded-lg">
            <div className="text-2xl font-mono">{recentBlinks.length}</div>
            <div className="text-sm text-muted-foreground">Samples</div>
          </div>
        </div>

        {/* Mini Timeline */}
        <div className="space-y-2">
          <div className="text-sm text-muted-foreground">Recent Activity</div>
          <div className="flex gap-1 h-12 items-end">
            {recentBlinks.slice(-20).map((rate, index) => {
              const height = ((rate - 5) / 20) * 100;
              let barColor = 'bg-green-500';
              if (rate < 10) barColor = 'bg-red-500';
              else if (rate < 15) barColor = 'bg-yellow-500';
              
              return (
                <div
                  key={index}
                  className={`flex-1 ${barColor} rounded-t transition-all`}
                  style={{ height: `${height}%`, minHeight: '2px' }}
                />
              );
            })}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}